
package View;

/**
  *
  * @author nouran 
  */
import Controller.threadServer;
import Model.Client;
import View.ClientWindow;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class Server extends JFrame implements ActionListener {

      
     JTextArea txaShow;
     JButton butBlq;
     JTextField userBlq;

     public Server() {
         super("Server Console");
         txaShow = new JTextArea();
         setLocationRelativeTo(null);
         userBlq = new JTextField(30);
         butBlq = new JButton("Block");
         butBlq.addActionListener(this);
        
         txaShow = new JTextArea();
         txaShow.setColumns(25);

         txaShow.setEditable(false);
         txaShow.setForeground(Color.BLUE);
         txaShow.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new Color(25, 10, 80)));

         JPanel panDown = new JPanel();
         panDown.setLayout(new BorderLayout());
         panDown.add(new JLabel(" Enter user to block: "), BorderLayout.WEST);
         panDown.add(userBlq, BorderLayout.CENTER);
         panDown.add(butBlq, BorderLayout.EAST);
        
         JPanel panUp = new JPanel();
         panUp.setLayout(new BorderLayout());
         panUp.add(new JScrollPane(txaShow), BorderLayout.CENTER);
        
         JPanel panCentral = new JPanel();
         panCentral.setLayout(new BorderLayout());
         panCentral.add(panDown, BorderLayout.SOUTH);
         panCentral.add(panUp,BorderLayout.NORTH);

         setLayout(new BorderLayout());
         add(panDown, BorderLayout.SOUTH);
         add(panUp, BorderLayout.CENTER);

         userBlq.requestFocus(); 
        
         setSize(450, 430);
         setLocation(120, 90);
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setVisible(true);

     }

     public void show(String msg) {
         txaShow.append(msg + "\n");
     }
    
     public String blockuser = "";
    
     public void actionPerformed(ActionEvent e) {
         blockuser = this.userBlq.getText();
     }

     public void runServer() {
         ServerSocket serv = null;  
         ServerSocket serv2 = null;  
         boolean listening = true;
         try {
             serv = new ServerSocket(8081);
             serv2 = new ServerSocket(8082);
             show(".::Server active :");
             while (listening) {
                 Socket sock = null, sock2 = null;
                 try {
                     show("Waiting for Users");
                     sock = serv.accept();
                     sock2 = serv2.accept();
                 } catch (IOException e) {
                     show("Accept failed: " + serv + ", " + e.getMessage());
                     continue;
                 }
                 threadServer user = new threadServer(sock, sock2, this);
                 user.start();
                   
             }

         } catch (IOException e) {
             show("error :" + e);
         }
     }
     public static void main(String abc[]) throws IOException {
         Server be = new Server();
         be.runServer();
     }


}