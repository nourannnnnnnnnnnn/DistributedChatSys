package View;

import Model.Client;  
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.JOptionPane.*;
import javax.swing.border.EmptyBorder;

 
   /**
  *
  * @author  nouran
  */
public class ClientWindow extends javax.swing.JFrame {

      
     @SuppressWarnings("unchecked")
       private void initComponents() {

         jPanel2 = new javax.swing.JPanel();
         jPanel1 = new javax.swing.JPanel();
         exit = new javax.swing.JButton();
         jScrollPane2 = new javax.swing.JScrollPane();
         lstAssets = new javax.swing.JList<>();
         Privatevent = new javax.swing.JToggleButton();
         users_connected = new javax.swing.JLabel();
         txtMessage = new javax.swing.JTextField();
         butSend = new javax.swing.JButton();
         LargeUserName = new javax.swing.JLabel();
         jScrollPane1 = new javax.swing.JScrollPane();
         panShow = new javax.swing.JTextArea();

         setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
         setBackground(new java.awt.Color(255, 255, 255));
         setLocation(new java.awt.Point(0, 0));
         setMinimumSize(new java.awt.Dimension(1135, 730));
         setResizable(false);
         setSize(new java.awt.Dimension(1200, 1200));

         jPanel2.setBackground(new java.awt.Color(18, 26, 47));
         jPanel2.setMinimumSize(new java.awt.Dimension(1120, 691));

         jPanel1.setBackground(new java.awt.Color(13, 19, 35));

         exit.setBackground(new java.awt.Color(102, 16, 242));
         exit.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
         exit.setForeground(new java.awt.Color(255, 255, 255));
         exit.setText("Log out");
         exit.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 exitActionPerformed(evt);
             }
         });

         lstAssets.setBackground(new java.awt.Color(23, 25, 55));
         lstAssets.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
         lstAssets.setForeground(new java.awt.Color(255, 255, 255));
         lstAssets.setModel(new javax.swing.AbstractListModel<String>() {
             String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
             public int getSize() { return strings.length; }
             public String getElementAt(int i) { return strings[i]; }
         });
         lstAssets.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
         lstAssets.setDragEnabled(true);
         lstAssets.setFixedCellHeight(35);
         lstAssets.setName(""); // NOI18N
         jScrollPane2.setViewportView(lstAssets);

         Privatevent.setBackground(new java.awt.Color(102, 16, 242));
         Privatevent.setFont(new java.awt.Font("Poppins", 0, 14));  
         Privatevent.setForeground(new java.awt.Color(255, 255, 255));
         Privatevent.setText("Private");
         Privatevent.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
            	 PrivateventActionPerformed(evt);
             }
         });

         users_connected.setFont(new java.awt.Font("Poppins", 0, 16));  
         users_connected.setForeground(new java.awt.Color(255, 255, 255));
         users_connected.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
         users_connected.setText("Connected users");

         javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
         jPanel1.setLayout(jPanel1Layout);
         jPanel1Layout.setHorizontalGroup(
             jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
             .addGroup(jPanel1Layout.createSequentialGroup()
                 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addGroup(jPanel1Layout.createSequentialGroup()
                         .addGap(32, 32, 32)
                         .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                             .addComponent(Privatevent, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                             .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                     .addComponent(jScrollPane2)
                                     .addComponent(exit, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE))))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                             .addGap(23, 23, 23)
                             .addComponent(users_connected, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                     .addContainerGap(28, Short.MAX_VALUE))
             );
             jPanel1Layout.setVerticalGroup(
                 jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                 .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                     .addContainerGap(47, Short.MAX_VALUE)
                     .addComponent(users_connected)
                     .addGap(27, 27, 27)
                     .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                     .addGap(18, 18, 18)
                     .addComponent(Privatevent, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                     .addGap(18, 18, 18)
                     .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                     .addGap(24, 24, 24))
             );

             txtMessage.setBackground(new java.awt.Color(102, 102, 102));
             txtMessage.setFont(new java.awt.Font("Poppins", 0, 14));  
             txtMessage.setForeground(new java.awt.Color(255, 255, 255));
             txtMessage.setMargin(new java.awt.Insets(0, 20, 0, 0));
             txtMessage.addActionListener(new java.awt.event.ActionListener() {
                 public void actionPerformed(java.awt.event.ActionEvent evt) {
                	 txtMessageActionPerformed(evt);
                 }
             });

             butSend.setBackground(new java.awt.Color(52, 128, 101));
             butSend.setFont(new java.awt.Font("Poppins", 1, 14));  
             butSend.setForeground(new java.awt.Color(255, 255, 255));
             butSend.setText("Send");
             butSend.addActionListener(new java.awt.event.ActionListener() {
                 public void actionPerformed(java.awt.event.ActionEvent evt) {
                     butSendActionPerformed(evt);
                 }
             });

             LargeUserName.setFont(new java.awt.Font("Poppins", 0, 18));  
             LargeUserName.setForeground(new java.awt.Color(255, 255, 255));
             LargeUserName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
             LargeUserName.setText("Name");

             panShow.setEditable(false);
             panShow.setBackground(new java.awt.Color(23, 25, 55));
             panShow.setColumns(20);
             panShow.setFont(new java.awt.Font("Poppins", 0, 14));  
             panShow.setForeground(new java.awt.Color(255, 255, 255));
             panShow.setRows(5);
             panShow.setCaretColor(new java.awt.Color(23, 25, 55));
             panShow.setMargin(new java.awt.Insets(20, 20, 20, 20));
             panShow.setMinimumSize(new java.awt.Dimension(21, 36));
             jScrollPane1.setViewportView(panShow);

             javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
             jPanel2.setLayout(jPanel2Layout);
             jPanel2Layout.setHorizontalGroup(
                 jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                 .addGroup(jPanel2Layout.createSequentialGroup()
                     .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                     .addGap(37, 37, 37)
                     .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                         .addGroup(jPanel2Layout.createSequentialGroup()
                             .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE)
                             .addGap(18, 18, 18)
                             .addComponent(butSend, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addComponent(LargeUserName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                         .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING))
                     .addContainerGap(45, Short.MAX_VALUE))
             );
             jPanel2Layout.setVerticalGroup(
                 jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                 .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                         .addGap(42, 42, 42)
                         .addComponent(LargeUserName)
                         .addGap(26, 26, 26)
                         .addComponent(jScrollPane1)
                         .addGap(18, 18, 18)
                         .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                             .addComponent(butSend, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                             .addComponent(txtMessage))
                         .addGap(28, 28, 28))
                 );

                 javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
                 getContentPane().setLayout(layout);
                 layout.setHorizontalGroup(
                     layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addGroup(layout.createSequentialGroup()
                         .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                         .addGap(0, 0, Short.MAX_VALUE))
                 );
                 layout.setVerticalGroup(
                     layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 );

                 pack();
                 setLocationRelativeTo(null);
             } 

             Vector<String> usernames;
             PrivateWindow PrivatEvent;
             Client client;
             public String user_name;

             private void butSendActionPerformed(java.awt.event.ActionEvent evt) { 
                 String message = txtMessage.getText();
                 client.stream(message);
                 txtMessage.setText("");
             } 

             private void txtMessageActionPerformed(java.awt.event.ActionEvent evt) { 
                 String message = txtMessage.getText();
                 client.stream(message);
                 txtMessage.setText("");
             } 

             private void PrivateventActionPerformed(java.awt.event.ActionEvent evt) { 
                 int pos = this.lstAssets.getSelectedIndex();
                 if (pos >= 0) {
                	 PrivatEvent.setFriend(usernames.get(pos));
                         PrivatEvent.setTitle(user_name+"'s Private Chat");
                	 PrivatEvent.setVisible(true);
                 }
             } 

             private void exitActionPerformed(java.awt.event.ActionEvent evt) { 
                 client.stream("Client " + user_name + " has disconnected...");
                 System.exit(0);
             } 

             public void sendMessage(String message) {
                 client.stream(message);
             }

             public JTextField getTxtMessage() {
                 return txtMessage;
             }

             public void setTxtMessage(JTextField txtMessage) {
                 this.txtMessage = txtMessage;
             }

             public void updateChats(Vector data) {
                 usernames = data;
                 lstAssets.remove(0);
                 putDataList(this.lstAssets, usernames);
             }

             public void setUserName(String user) {
            	 LargeUserName.setText("General chat of " + user);
             }

             public void showMsg(String msg) {
                 this.panShow.append(msg + "\n\n\n");
             }

             public void putAssets( Vector data) {
            	 changeNumber(data);
                 usernames = data;
                 putDataList(this.lstAssets, usernames);
             }

             public void changeNumber(Vector data ) {
                 this.users_connected.setText("There are " + data.size() + " connected users");
             }

             public void addUser(String user) {
                 usernames.add(user);
                 changeNumber(usernames);
                 putDataList(this.lstAssets, usernames);
             }

             public void removeUser(String user) {
                 usernames.remove(user);
                 putDataList(this.lstAssets, usernames);
             }

             private void putDataList(JList list, final Vector data) {
                 list.setModel(new AbstractListModel() {
                     @Override
                     public int getSize() {
                         return data.size();
                     }

                     @Override
                     public Object getElementAt(int i) {
                         return data.get(i);
                     }
                 });
             }

            
             public void lock(String user) {
                 this.txtMessage.setEnabled(false);
             }
             

             public void messageFriend(String friend, String msg) {
                 PrivatEvent.setFriend(friend);
                 PrivatEvent.showMsg(msg);
                 PrivatEvent.setTitle(user_name+"'s Private Chat");
                 PrivatEvent.setVisible(true);
             }

             public void block() {
                 this.butSend.setEnabled(false);
                 this.txtMessage.setEnabled(false);
             }

             public ClientWindow(String user) throws IOException {

                 initComponents();
                 this.setTitle("Client window - " + user);

                 user_name = user;

                 client = new Client(this);
                 client.connection(user);
                 Vector<String> test = new Vector();
                 test = client.askUsers();

                 int counter = 0;

                 for (int i = 0; i < test.size(); i++) {
                     if (test.get(i).equals(user)) {
                         counter++;
                     }
                 }

                 if (counter > 1) {
                     JOptionPane.showMessageDialog(null, "The user is already logged in");
                     System.exit(0);
                 } else {
                     JOptionPane.showMessageDialog(null, "Welcome  " + user);
                     usernames = new Vector();
                     putAssets(client.askUsers());
                     PrivatEvent = new PrivateWindow(client);

                     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     setVisible(true);
                 }
             }


             
             public javax.swing.JButton butSend;
             public javax.swing.JToggleButton Privatevent;
             private javax.swing.JPanel jPanel1;
             private javax.swing.JPanel jPanel2;
             private javax.swing.JScrollPane jScrollPane1;
             private javax.swing.JScrollPane jScrollPane2;
             public javax.swing.JList<String> lstAssets;
             public javax.swing.JLabel LargeUserName;
             public javax.swing.JTextArea panShow;
             public javax.swing.JButton exit;
             public javax.swing.JTextField txtMessage;
             private javax.swing.JLabel users_connected;
            

        }