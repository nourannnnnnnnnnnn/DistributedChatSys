package Controller;


import View.ClientWindow;
import View.ClientWindow;
import java.net.*;
import java.lang.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
  *
  * @author nouran
  */

public class threadClient extends Thread {

     DataInputStream input;
     
      ClientWindow vcli; // GUI

     public threadClient(DataInputStream input, ClientWindow vcli) throws IOException {
         this.input = input;
         this.vcli = vcli;
     }

     public void run() {
         String menser = "", friend = "";
         int option = 0;
         while (true) {

             try {
                 option = input.readInt();
                 switch (option) {
                     case 1://message sent
                         menser = input.readUTF();
                         System.out.println("Server ECHO:" +  ( menser));
                         vcli.showMsg( ( menser));
                         break;
                     case 2://adds
                         menser = input.readUTF();
                         vcli.addUser(menser);
                         break;
                     case 3://friend message
                         friend = input.readUTF();
                         menser = input.readUTF();
                         vcli.messageFriend(friend,  ( menser));
                         System.out.println("Server ECHO:" +  ( menser));
                         break;
                     case 4:
                         menser = input.readUTF();
                         vcli.sendMessage("I have been blocked from this chat. Goodbye!");
                         vcli.block();
                         break;
                 }
             } catch (IOException e) {
                 System.out.println("Communication error " + "User information");
                 break;
             }
         }
         System.out.println("server disconnected");
     }
     
     
  //   private static final String key = "YourSecretKeyaym"; // 16 characters for AES-128
     private static final char SECRET_CHAR = 'X'; // Secret character for XOR operation
     
     private String decrypt(String strToDecrypt) throws IOException{
 
    	 String str= strToDecrypt, nstr="";
         char ch;
        
         
       for (int i=0; i<str.length(); i++)
       {
         ch= str.charAt(i); //extracts each character
         nstr= ch+nstr; //adds each character in front of the existing string
       }
      return  ( nstr); 
    	 
    	 
  		//return "clear message";//"dec|| "+mencli;
  	}
     
     private String encrypt(String strToEncrypt) {
    	 
    	 String str= strToEncrypt, nstr="";
         char ch;
        
         
       for (int i=0; i<str.length(); i++)
       {
         ch= str.charAt(i); //extracts each character
         nstr= ch+nstr; //adds each character in front of the existing string
       }
      return  ( nstr);
           
    	 
		//  return "blabla"; // "enc|| "+mencli;
	}
    
     
     
     
}