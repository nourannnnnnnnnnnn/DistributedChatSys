package Controller;

 
   
import View.Server;
import View.ClientWindow;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;


import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
//import java.util.Base64;
//import javax.crypto.Cipher;
//import javax.crypto.spec.SecretKeySpec;

/**
  *
  * @author nouran
  */
public class threadServer extends Thread {

     Socket scli = null;
     Socket scli2 = null;
     DataInputStream input = null;
     DataOutputStream output = null;
     DataOutputStream output2 = null;
     public static Vector<threadServer> activeclients = new Vector();
     String nameUser;
     Server serv;

     public threadServer(Socket sclient, Socket sclient2, Server serv) {
         scli = sclient;
         scli2 = sclient2;
         this.serv = serv;
         nameUser = "";
         activeclients.add(this);
          
     }

     public String getNameUser() {
         return nameUser;
     }

     public void setNameUser(String name) {
         nameUser = name;
     }

     public void run() {
         serv.show(".::Waiting for Messages:");

         try {
             input = new DataInputStream(scli.getInputStream());
             
             output = new DataOutputStream(scli.getOutputStream());
             output2 = new DataOutputStream(scli2.getOutputStream());
             this.setNameUser(input.readUTF());
             sendUserAssets();
         } catch (IOException e) {
             e.printStackTrace();
         }

         int option = 0, numUsers = 0;
         String friend = "", mencli = "", userBlock = "";

         while (true) {
             try {

                 String name_to_block = serv.blockuser;

                 if (name_to_block != "") {
                     option = 4;
                 } else {
                     option = input.readInt();
                 }
serv.show("user is connected "+getNameUser());
                 switch (option) {
                     case 1://hab3t lkolo 
                         mencli = input.readUTF();
                         serv.show(getNameUser() + " is saying : (cryptedMessage) [" +  encrypt(mencli)+"]");
                         sendMsg( (mencli));
                         break;
                         
                     case 2://sending asset list
                         numUsers = activeclients.size();
                         output.writeInt(numUsers);
                         
                         for (int i = 0; i < numUsers; i++) {
                             output.writeUTF(activeclients.get(i).nameUser);
                         }
                         break;
                     case 3: // send message to only one
                         friend = input.readUTF();//capture friendname
                         mencli = input.readUTF();//message sent
                         sendMsg(friend,  (mencli));
                          serv.show(this.nameUser+" is sending private message to  " + friend);
                         break;
                     case 4: // Block the user
                         userBlock = name_to_block;
                         serv.show(name_to_block);
                         serv.show("User has been blocked: " + name_to_block);
                         blockUser(userBlock);
                         serv.blockuser = name_to_block = "";
                         option = 0;
                         break;
                 }
             } catch (IOException e) {
                 System.out.println("The client terminated the connection");
                 break;
             }
         }
         serv.show("A user was removed: "+this.nameUser);
         activeclients.removeElement(this);

         try {
             serv.show("A user logged out: "+this.nameUser);
             scli.close();
         } catch (Exception et) {
             serv.show("cannot close socket");
         }
     }

    

	public void blockUser(String userN) throws IOException { // btndh option 4
         threadServer user = null;
         for (int i = 0; i < activeclients.size(); i++) {
             try {
                 if (activeclients.get(i).getNameUser().equals(userN)) {
                     user = activeclients.get(i);
                     user.output2.writeInt(4);// eli hwa hay3mlo block!!
                     user.output2.writeUTF(userN);
                     serv.blockuser = ""; // mn server kman!!
                 }

             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
     }

     public void sendMsg(String mencli2) { // option 1 
         threadServer user = null;
         for (int i = 0; i < activeclients.size(); i++) {
             serv.show("Encrypted message diffused : [" + encrypt(mencli2)+"]");
             try {
                 user = activeclients.get(i);
                 user.output2.writeInt(1);//message option
                 user.output2.writeUTF("" + this.getNameUser() + ": " + mencli2);
             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
     }

     public void sendUserAssets() {
         threadServer user = null;
         for (int i = 0; i < activeclients.size(); i++) {
             try {
                 user = activeclients.get(i);
                 if (user == this) {
                     continue;//I already sent it to you
                 }
                 user.output2.writeInt(2);//add option
                 user.output2.writeUTF(this.getNameUser());
             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
     }

     
     private void sendMsg(String friend, String mencli) {
         threadServer user = null;
         for (int i = 0; i < activeclients.size(); i++) {
             try {
                 user = activeclients.get(i);
                 
                 if (user.nameUser.equals(friend)) {
                     user.output2.writeInt(3);//friend message option
                     user.output2.writeUTF(this.getNameUser());
                     user.output2.writeUTF("" + this.getNameUser() + ": " + mencli);
                 }
             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
     }
     
     
     private String encrypt(String strToEncrypt) {
 
    	 String str= strToEncrypt, nstr="";
         char ch;
        
         
       for (int i=0; i<str.length(); i++)
       {
         ch= str.charAt(i); //extracts each character
         nstr= ch+nstr; //adds each character in front of the existing string
       }
      return  ( nstr);
           
    	 
		//  return "blabla"; // "enc|| "+mencli;
	}
    
     private String decrypt(String strToDecrypt) throws IOException{
    	 
    	 String str= strToDecrypt, nstr="";
         char ch;
        
         
       for (int i=0; i<str.length(); i++)
       {
         ch= str.charAt(i); //extracts each character
         nstr= ch+nstr; //adds each character in front of the existing string
       }
      return  ( nstr); 
    	 
    	 
  		//return "clear message";//"dec|| "+mencli;
  	}
     
     
     
     
     
}