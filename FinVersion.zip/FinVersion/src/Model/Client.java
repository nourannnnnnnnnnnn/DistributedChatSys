 
package Model;

import Controller.threadClient;
import View.ClientWindow;
import java.io.*;
import java.net.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
  *
  * @author nouran
  */
public class Client {

     public static String IP_SERVER;
     ClientWindow vent;
     DataInputStream input = null;
     DataOutputStream output = null;
     DataInputStream input2 = null;
     Socket communication = null;  
     Socket communication2 = null;  

     String clientName;
     private String user;

     /**
      * Creates a new instance of Client
      */
     public Client(ClientWindow vent) throws IOException {
         this.vent = vent;
     }

     public Client() {
     }

     public void connection(String user) throws IOException {
         try {
             communication = new Socket(Client.IP_SERVER, 8081);
             communication2 = new Socket(Client.IP_SERVER, 8082);
             input = new DataInputStream(communication.getInputStream());
             output = new DataOutputStream(communication.getOutputStream());
             input2 = new DataInputStream(communication2.getInputStream());
             clientName = user;
             vent.setUserName(user);
             output.writeUTF(clientName);
         } catch (IOException e) {
             JOptionPane.showMessageDialog(null, "The server at that server ip is not up");
         }
         new threadClient(input2, vent).start();
     }

     public String getName() {
         return clientName;
     }

     public Vector<String> askUsers() {
         Vector<String> users = new Vector();
         try {
             output.writeInt(2);
             int numUsers = input.readInt();
             for (int i = 0; i < numUsers; i++) {
                 users.add(input.readUTF());
             }
         } catch (IOException ex) {
             System.err.println("An error has occurred");
         }
         return users;
     }

     public void stream(String mens) {
         try {
             System.out.println(getName() + ":"
                     +mens);
             output.writeInt(1);
             output.writeUTF(mens);
         } catch (IOException e) {
             System.out.println("error...." + e);
         }
     }

     public void stream(String friend, String mens) {
         try {
             System.out.println(getName() + ":"
                     +mens);
             output.writeInt(3); 
             output.writeUTF(friend);
             output.writeUTF(mens);
         } catch (IOException e) {
             System.out.println("error...." + e);
         }
     }

}